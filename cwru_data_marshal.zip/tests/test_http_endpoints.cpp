#include <catch2/catch_all.hpp>
#include <boost/asio.hpp>
#include <boost/beast/http.hpp>


TEST_CASE("dummy http test placeholder"){
REQUIRE(true);
}